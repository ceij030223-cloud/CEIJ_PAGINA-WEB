<?php
include 'db.php';

$claveAdmin = 'adminceij123';

// Verificar clave
if (!isset($_GET['admin']) || $_GET['admin'] !== $claveAdmin) {
    die("Acceso no autorizado.");
}

// Acción
$action = $_GET['action'] ?? 'lista';
$baseUrl = 'editar.php?admin=' . $claveAdmin;

function esc($str) {
    return htmlspecialchars($str, ENT_QUOTES);
}

if ($action === 'editar' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $titulo = $conexion->real_escape_string($_POST['titulo']);
        $descripcion = $conexion->real_escape_string($_POST['descripcion']);
        $duracion = $conexion->real_escape_string($_POST['duracion']);
        $alumnos = $conexion->real_escape_string($_POST['alumnos']);
        $fecha = $conexion->real_escape_string($_POST['fecha']);
        $horario = $conexion->real_escape_string($_POST['horario']);
        $dias = $conexion->real_escape_string($_POST['dias']);

        if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
            $imagen_nombre = basename($_FILES['imagen']['name']);
            $imagen_tmp = $_FILES['imagen']['tmp_name'];
            $carpeta_destino = 'img/';
            if (!is_dir($carpeta_destino)) mkdir($carpeta_destino, 0755, true);
            $ruta = $carpeta_destino . $imagen_nombre;
            move_uploaded_file($imagen_tmp, $ruta);

            $query = "UPDATE cursos SET 
              titulo='$titulo', descripcion='$descripcion', duracion='$duracion',
              alumnos='$alumnos', fecha='$fecha', horario='$horario', dias='$dias',
              imagen='$ruta' WHERE id=$id";
        } else {
            $query = "UPDATE cursos SET 
              titulo='$titulo', descripcion='$descripcion', duracion='$duracion',
              alumnos='$alumnos', fecha='$fecha', horario='$horario', dias='$dias' 
              WHERE id=$id";
        }

        if ($conexion->query($query)) {
            header("Location: $baseUrl&action=lista");
            exit();
        } else {
            $error = "Error al actualizar el curso: " . $conexion->error;
        }
    }

    $resultado = $conexion->query("SELECT * FROM cursos WHERE id=$id");
    if ($resultado->num_rows === 0) die("Curso no encontrado.");
    $curso = $resultado->fetch_assoc();
} elseif ($action === 'eliminar' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);
    $conexion->query("DELETE FROM cursos WHERE id=$id");
    header("Location: $baseUrl&action=lista");
    exit();
} else {
    $resultado = $conexion->query("SELECT * FROM cursos ORDER BY id DESC");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Panel Admin - Cursos</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="icon" href="../icon/ceijicon.ico"/>
  <link rel="stylesheet" href="../css/index.css" />
</head>
<style>
/* Formulario */
.form-card {
  width: 90%;
  max-width: 650px;
  margin: 30px auto;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.08);
  overflow: hidden;
  font-family: Arial, sans-serif;
}

.card-header {
  background-color: #e45e1b;
  color: white;
  padding: 15px 20px;
}

.card-header h4 {
  margin: 0;
}

.card-body {
  padding: 20px;
  font-size: 0.95rem;
}

/* Floating labels */
.input-container {
  position: relative;
  margin-bottom: 20px;
}

.input-container input,
.input-container textarea {
  width: 100%;
  padding: 12px;
  border: 2px solid #ccc;
  border-radius: 6px;
  outline: none;
  font-size: 16px;
  background: none;
}

.input-container label {
  position: absolute;
  top: 12px;
  left: 12px;
  padding: 0 5px;
  font-size: 14px;
  color: #777;
  pointer-events: none;
  background: white;
  transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease;
}

.input-container input:focus,
.input-container textarea:focus {
  border-color: #e45e1b;
  box-shadow: 0 0 0 3px rgba(0, 81, 255, 0.15);
}

.input-container input:focus + label,
.input-container input:not(:placeholder-shown) + label,
.input-container textarea:focus + label,
.input-container textarea:not(:placeholder-shown) + label {
  transform: translateY(-20px);
  font-size: 12px;
  color: #e45e1b;
}

/* Botones */
.form-actions {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.form-actions .btn {
  padding: 10px 15px;
  border-radius: 6px;
  font-size: 15px;
}

.btn-success, .btn-secondary {
  background: #e45e1b;
  border: none;
  color: white;
  transition: background 0.2s ease;
}

.btn-success:hover, .btn-secondary:hover {
  background: #d64e0f;
}

/* Navbar */
nav.navbar {
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
  background-color: #e45e1b;
}

.navbar-nav {
  display: flex;
  gap: 25px;
}

.navbar-nav .nav-link {
  position: relative;
  font-family: Arial, Helvetica, sans-serif;
  color: white !important;
  padding-bottom: 5px;
  transition: transform 0.3s ease;
}

.navbar-nav .nav-link::after {
  content: "";
  position: absolute;
  bottom: 0;
  left: 0;
  width: 0;
  height: 2px;
  background-color: #fff;
  transition: width 0.3s ease;
}

.navbar-nav .nav-link:hover::after,
.navbar-nav .nav-link.active::after {
  width: 100%;
}

/* Tarjetas */
.card img {
  width: 100%;
  height: auto;
  border-radius: 6px 6px 0 0;
}

.card-footer {
  font-size: 0.9rem;
  padding: 10px;
}

/* Responsive */
@media (max-width: 576px) {
  .form-card {
    margin: 20px auto;
  }
  .card-body {
    font-size: 0.9rem;
  }
  .form-actions {
    flex-direction: column;
  }
}
</style>
<body>

<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" style="color: #e45e1b; border: 10px;">
      <i class="bi bi-list" style="color: white; font-size: 1.5rem;"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link <?php if($action==='insertar') echo 'active'; ?>" href="admin.php?admin=<?php echo $claveAdmin; ?>">Agregar curso</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($action==='lista') echo 'active'; ?>" href="<?php echo $baseUrl; ?>&action=lista">Actualizar curso</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <?php if (isset($error)): ?>
    <div class="alert alert-danger"><?php echo esc($error); ?></div>
  <?php endif; ?>

  <?php if ($action === 'editar' && isset($curso)): ?>
    <div class="card form-card">
      <div class="card-header"><h4>Editar Curso</h4></div>
      <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
          <?php 
          $campos = ['titulo'=>'Título','descripcion'=>'Descripción','duracion'=>'Duración','alumnos'=>'Alumnos','fecha'=>'Fecha','horario'=>'Horario','dias'=>'Días'];
          foreach($campos as $name=>$label):
              $value = esc($curso[$name]);
              $type = $name==='descripcion'?'textarea':'input';
          ?>
          <div class="input-container">
            <?php if($type==='input'): ?>
            <input type="<?= $name==='alumnos'?'number':'text'; ?>" name="<?= $name; ?>" id="<?= $name; ?>" class="form-control" value="<?= $value; ?>" required placeholder=" ">
            <?php else: ?>
            <textarea name="<?= $name; ?>" id="<?= $name; ?>" class="form-control" rows="4" required placeholder=" "><?= $value; ?></textarea>
            <?php endif; ?>
            <label for="<?= $name; ?>"><?= $label; ?></label>
          </div>
          <?php endforeach; ?>

          <div class="mb-3">
            <label class="form-label">Imagen actual</label><br>
            <img src="<?php echo esc($curso['imagen']); ?>" alt="Imagen" style="width: 100%; max-width: 400px; border-radius: 6px;">
          </div>

          <div class="input-container">
            <input type="file" name="imagen" id="imagen" class="form-control" accept="image/*">
            <label for="imagen">Cambiar imagen (opcional)</label>
          </div>

          <div class="form-actions">
            <button class="btn btn-success">Guardar Cambios</button>
            <a href="<?php echo $baseUrl; ?>&action=lista" class="btn btn-secondary">Cancelar</a>
          </div>
        </form>
      </div>
    </div>

  <?php elseif ($action === 'lista'): ?>
    <h2>Cursos Registrados</h2>
    <div class="row row-cols-1 row-cols-sm-1 row-cols-md-2 row-cols-lg-3 g-4">
      <?php while ($curso = $resultado->fetch_assoc()): ?>
        <div class="col">
          <div class="card h-100 shadow-sm">
            <img src="<?php echo esc($curso['imagen']); ?>" class="card-img-top" alt="Imagen del curso">
            <div class="card-body">
              <h5 class="card-title"><?php echo esc($curso['titulo']); ?></h5>
              <p class="card-text"><?php echo esc($curso['descripcion']); ?></p>
            </div>
            <div class="card-footer d-flex flex-column align-items-center gap-2 text-white" style="background: linear-gradient(135deg, #e45e1b, #e45e1b);">
              <div class="d-flex justify-content-center gap-4 flex-wrap">
                <small><i class="bi bi-calendar-event"></i> <?php echo esc($curso['fecha']); ?></small>
                <small><i class="bi bi-alarm"></i> <?php echo esc($curso['horario']); ?></small>
              </div>
              <hr style="border: 1px ; width: 100%;">
              <div class="d-flex justify-content-between w-100 px-3 flex-wrap">
                <small><i class="bi bi-clock-history"></i> <?php echo esc($curso['duracion']); ?></small>
                <small><i class="bi bi-calendar-week"></i> <?php echo esc($curso['dias']); ?></small>
                <small><i class="bi bi-people-fill"></i> <?php echo esc($curso['alumnos']); ?> alumnos</small>
              </div>
              <div class="mt-2 d-flex justify-content-center gap-2 flex-wrap">
                <a href="<?php echo $baseUrl; ?>&action=editar&id=<?php echo $curso['id']; ?>" class="btn btn-dark btn-sm">
                  <i class="bi bi-pencil"></i> Editar
                </a>
                <a href="<?php echo $baseUrl; ?>&action=eliminar&id=<?php echo $curso['id']; ?>" 
                   class="btn btn-dark btn-sm"
                   onclick="return confirm('¿Seguro que quieres eliminar este curso?');">
                  <i class="bi bi-trash"></i> Eliminar
                </a>
              </div>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>