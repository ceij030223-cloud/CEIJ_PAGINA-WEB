<?php
include 'db.php';

$claveAdmin = 'adminceij123';

// Verificar clave de acceso en URL
if (!isset($_GET['admin']) || $_GET['admin'] !== $claveAdmin) {
    die("Acceso no autorizado.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = $conexion->real_escape_string($_POST['titulo']);
    $descripcion = $conexion->real_escape_string($_POST['descripcion']);
    $duracion = $conexion->real_escape_string($_POST['duracion']);
    $alumnos = $conexion->real_escape_string($_POST['alumnos']);
    $fecha = $conexion->real_escape_string($_POST['fecha']);
    $horario = $conexion->real_escape_string($_POST['horario']);
    $dias = $conexion->real_escape_string($_POST['dias']);

    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $imagen_nombre = basename($_FILES['imagen']['name']);
        $imagen_tmp = $_FILES['imagen']['tmp_name'];

        // Crear carpeta si no existe
        $carpeta_destino = 'ceij/img/';
        if (!is_dir($carpeta_destino)) {
            mkdir($carpeta_destino, 0755, true);
        }

        $ruta = $carpeta_destino . $imagen_nombre;

        // Mover imagen
        if (move_uploaded_file($imagen_tmp, $ruta)) {
            $query = "INSERT INTO cursos (titulo, descripcion, imagen, duracion, alumnos, fecha, horario, dias) 
                      VALUES ('$titulo', '$descripcion', '$ruta', '$duracion', '$alumnos', '$fecha', '$horario', '$dias')";

            if ($conexion->query($query)) {
                // Redirigir y mantener la clave en la URL
               // Redirigir con mensaje de éxito
                header("Location: admin.php?admin=$claveAdmin&msg=ok");
                exit();
            } else {
                echo "Error al guardar el curso: " . $conexion->error;
            }
        } else {
            echo "Error al mover la imagen subida.";
        }
    } else {
        echo "Error al subir la imagen.";
    }
} else {
    echo "Método no permitido.";
}
?>
