<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <link rel="stylesheet" href="../css/index.css" />
  <link rel="icon" href="../icon/ceijicon.ico"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
  <title>Modo admin</title>
  <style>
    /* Navbar */
    nav.navbar {
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
      background-color: ##e45e1b;
    }
    .navbar-nav {
      display: flex;
      gap: 25px;
    }
    .navbar-nav .nav-link {
      position: relative;
      font-family: Arial, Helvetica, sans-serif;
      color: white !important;
      padding-bottom: 5px;
    }
    .navbar-nav .nav-link::after {
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 0;
      height: 2px;
      background-color: #fff;
      transition: width 0.3s ease;
    }
    .navbar-nav .nav-link:hover::after,
    .navbar-nav .nav-link.active::after {
      width: 100%;
    }

    /* Contenedor para centrar */
    .form-container {
      max-width: 650px;
      margin: 40px auto;
      padding: 0; /* Sin padding adicional */
      background: none; /* Sin fondo */
      border-radius: 0; /* Sin bordes redondeados */
      box-shadow: none; /* Sin sombra */
    }

    /* Card */
    .form-card {
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.08);
      overflow: hidden;
      font-family: Arial, sans-serif;
    }
    nav{
          background-color: #e45e1b;

    }
    .card-header {
      background: #e45e1b;
      color: white;
      padding: 15px 20px;
    }
    .card-body {
      padding: 20px;
    }

    /* Floating labels */
    .input-container {
      position: relative;
      margin-bottom: 20px;
    }
    .input-container input,
    .input-container textarea {
      width: 100%;
      padding: 12px;
      border: 2px solid #ccc;
      border-radius: 6px;
      outline: none;
      font-size: 16px;
      background: none;
    }
    .input-container label {
      position: absolute;
      top: 12px;
      left: 12px;
      padding: 0 5px;
      font-size: 14px;
      color: #777;
      pointer-events: none;
      background: white;
      transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease;
    }
    .input-container input:focus,
    .input-container textarea:focus {
      border-color: #e45e1b;
      box-shadow: 0 0 0 3px rgba(0, 81, 255, 0.15);
    }
    .input-container input:focus + label,
    .input-container input:not(:placeholder-shown) + label,
    .input-container textarea:focus + label,
    .input-container textarea:not(:placeholder-shown) + label {
      transform: translateY(-20px);
      font-size: 12px;
      color: #e45e1b;
    }

    /* Botón */
    .btn-success {
      background: #e45e1b;
      border: none;
    }
    .btn-success:hover {
      background: #e45e1b;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" style="color: #e45e1b; border: 10px;">
        <i class="bi bi-list" style="color: white; font-size: 1.5rem;"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item"><a class="nav-link" href="admin.php?admin=adminceij123">Agregar curso</a></li>
          <li class="nav-item"><a class="nav-link" href="editar.php?admin=adminceij123">Actualizar curso</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <?php
  if (!isset($_GET['admin']) || $_GET['admin'] !== 'adminceij123') {
      die("Acceso no autorizado.");
  }
  ?>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'ok'): ?>
    <div class="alert alert-success text-center mt-3">
      ¡Curso agregado exitosamente!
    </div>
  <?php endif; ?>

  <div class="form-container">
    <div class="card form-card">
      <div class="card-header">
        <h4>Agregar Curso</h4>
      </div>
      <div class="card-body">
        <form action="insertar.php?admin=adminceij123" method="POST" enctype="multipart/form-data">
          <div class="input-container">
            <input type="text" name="titulo" id="titulo" required placeholder=" ">
            <label for="titulo">Título</label>
          </div>
          <div class="input-container">
            <textarea name="descripcion" id="descripcion" rows="6" required placeholder=" "></textarea>
            <label for="descripcion">Descripción</label>
          </div>
          <div class="input-container">
            <input type="text" name="duracion" id="duracion" required placeholder=" ">
            <label for="duracion">Duración</label>
          </div>
          <div class="input-container">
            <input type="number" name="alumnos" id="alumnos" required placeholder=" ">
            <label for="alumnos">Número de alumnos</label>
          </div>
          <div class="input-container">
            <input type="file" name="imagen" id="imagen" accept="image/*" required>
            <label for="imagen">Imagen</label>
          </div>
          <div class="input-container">
            <input type="text" name="fecha" id="fecha" required placeholder=" ">
            <label for="fecha">Fecha de inicio</label>
          </div>
          <div class="input-container">
            <input type="text" name="horario" id="horario" required placeholder=" ">
            <label for="horario">Horario</label>
          </div>
          <div class="input-container">
            <input type="text" name="dias" id="dias" required placeholder=" ">
            <label for="dias">Días</label>
          </div>
          <button type="submit" class="btn btn-success w-100">Agregar Curso</button>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
