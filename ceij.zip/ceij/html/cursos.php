<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <link rel="stylesheet" href="../css/index.css" />
  <link rel="icon" href="../icon/ceijicon.ico" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
  <title>Cursos</title>
  <style>
    /* Estilos específicos para las cards de cursos */
    .curso-card {
      border: none;
      border-radius: 12px;
      overflow: hidden;
      transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      box-shadow: 0 6px 18px rgba(0,0,0,0.12);
      margin-bottom: 25px;
      height: 100%;
      background: linear-gradient(145deg, #ffffff, #f8f9fa);
    }
    
    .curso-card:hover {
      transform: translateY(-8px) scale(1.02);
      box-shadow: 0 15px 35px rgba(0,0,0,0.18);
    }
    
    .curso-card .card-img-top {
  width: 100%;
  height: auto; /* la imagen conserva proporción natural */
  aspect-ratio: 16/9; /* proporción panorámica */
  object-fit: cover; /* rellena el espacio sin deformarse */
  transition: transform 0.5s ease;
  border-bottom: 4px solid #e45e1b;
}

    
    .curso-card:hover .card-img-top {
      transform: scale(1.08);
    }
    
    
    .curso-card .card-body {
      padding: 1.5rem;
      position: relative;
    }
    
    .curso-card .card-title {
      color: #2c3e50;
      font-weight: 700;
      margin-bottom: 1rem;
      font-size: 1.25rem;
      min-height: 60px;
      position: relative;
      padding-bottom: 10px;
    }
    
    .curso-card .card-title:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 50px;
      height: 3px;
      background: linear-gradient(90deg, #e45e1b, #e45e1b);
      border-radius: 3px;
    }
    
    .curso-card .card-text {
      color: #555;
      line-height: 1.6;
      margin-bottom: 1.5rem;
      font-size: 0.95rem;
    }
    
    .curso-card .card-footer {
      background: linear-gradient(135deg, #e45e1b, #e45e1b);
      color: white;
      font-weight: 500;
      border-top: none;
      padding: 0.8rem 1.5rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .curso-card .card-footer small {
      display: flex;
      align-items: center;
    }
  
    .curso-card .card-footer i {
      margin-right: 6px;
      font-size: 1rem;
    }
    /* Agregado: Fuente y estilo para nav links */
     /* Navbar con línea animada y separación */
    nav.navbar {
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
      
    }

    .navbar-nav {
      display: flex;
      gap: 25px;
    }

    .navbar-nav .nav-link {
      position: relative;
      font-family: Arial, Helvetica, sans-serif;
      color: white !important;
      padding-bottom: 5px;
      transition: transform 0.3s ease;
    }

    .navbar-nav .nav-link::after {
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 0;
      height: 2px;
      background-color: #fff;
      transition: width 0.3s ease;
    }

    .navbar-nav .nav-link:hover::after {
      width: 100%;
    }

    .navbar-nav .nav-link.active::after {
      width: 100%;
    }
    

    .badge-curso {
      position: absolute;
      top: -15px;
      right: 15px;
      color: white;
      font-weight: 700;
      padding: 0.4em 0.8em;
      border-radius: 50px;
      font-size: 0.75em;
      box-shadow: 0 4px 8px rgba(255,107,53,0.3);
      z-index: 2;
    }
   

    @media (max-width: 768px) {
      .curso-card .card-title {
        min-height: auto;
      }
      
    .curso-card .card-img-top {
    aspect-ratio: 4/3; /* en móvil un poco más cuadrada */
  }
    }

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

.main {
    display: flex;
    justify-content: flex-end;
    align-items: flex-end;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
    min-height: 45vh;
}

footer {
    position: relative;
    width: 100%;
    background: #e45e1b;
    min-height: 100px;
    padding: 20px 50px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
}

footer .social_icon,
footer .menu {
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 10px 0;
    flex-wrap: wrap;
}

footer .social_icon li,
footer .menu li {
    list-style: none;}

footer .social_icon li a {
    font-size: 2em;
    color: #fff;
    margin: 0 10px;
    display: inline-block;
    transition: 0.5s;
}

footer .social_icon li a {
    transform: translateY(-10px);
}

footer .menu li a {
    font-size: 1.2em;
    color: #fff;
    margin: 0 10px;
    display: inline-block;
    text-decoration: none;
    opacity: 0.75;
}

footer .menu li a:hover {

    opacity: 1;
}

footer p {
    color: #fff;
    text-align: center;
    margin-top: 15px;
    margin-bottom: 10px;
    font-size: 1.1em;
}


footer .wave {
    position: absolute;
    top: -100px;
    left: 0;
    width: 100%;
    height: 100px;
    background: url(wave1.png);
    background-size: 1000px 100px;
}
footer .wave#wave1 {
    z-index: 1000;
    opacity: 1;
    bottom: 0;
    animation: animatewave 3s linear infinite;
}


@keyframes animatewave {
    0% {
        background-position-x: 0px;
    }

    100% {
        background-position-x: 1000px;
    }

}


.zoom li a {
    transition: 1s;
}

.zoom li a:hover {
    transform: scale(1.1);
}
  </style>
</head>
<body>
    <!-- Navbar Bootstrap -->
<nav class="navbar navbar-expand-lg" style="background-color: #e45e1b;">
  <div class="container-fluid">
    <!-- Botón para móvil -->
    <button class="btn d-lg-none text-white" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileNavbar" aria-controls="mobileNavbar">
      <i class="bi bi-list" style="font-size: 1.5rem;"></i>
    </button>

    <!-- Logo -->
    <a class="navbar-brand ms-2" href="#">
      <img src="../img/sin fondo.png" alt="Logo" style="height:37px;">
    </a>

    <!-- Navbar normal desktop -->
    <div class="collapse navbar-collapse d-none d-lg-flex">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link text-white" href="index.html">Inicio</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="cursos.php">Cursos</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="areadepracticas.html">Área de Práctica</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="nosotros.html">Nosotros</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="https://forms.gle/ZTZrzaAK1NZHGCKE6" target="_blank">Inscríbete</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link text-white" href="#" role="button" data-bs-toggle="dropdown">Galería</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="Galerias.html#seccion1">SolidWorks Básico</a></li>
            <li><a class="dropdown-item" href="Galerias.html#seccion2">Control Eléctrico Industrial</a></li>
            <li><a class="dropdown-item" href="Galerias.html#seccion3">Programación CNC</a></li>
            <li><a class="dropdown-item" href="Galerias.html#seccion4">Instalaciones Eléctricas</a></li>
            <li><a class="dropdown-item" href="Galerias.html#seccion5">Mantenimiento Minisplit</a></li>
            <li><a class="dropdown-item" href="Galerias.html#seccion6">Marketing Digital</a></li>
            <li><a class="dropdown-item" href="Galerias.html#seccion7">Programación PLC</a></li>
            <li><a class="dropdown-item" href="Galerias.html#seccion8">Respuesta Inmediata contra Incendios</a></li>
            <li><a class="dropdown-item" href="Galerias.html#seccion9">Montacargas</a></li>
            <li><a class="dropdown-item" href="Galerias.html#seccion10">Condiciones de Seguridad Para Realizar Trabajos en Trabajos en Altura</a></li>
          </ul>
        </li>
        <li class="nav-item"><a class="nav-link text-white" href="ubicanos.html">Ubícanos</a></li>
      </ul>
    </div>

    <!-- Offcanvas para móvil -->
    <div class="offcanvas offcanvas-start custom-offcanvas  d-lg-none" tabindex="-1" id="mobileNavbar" aria-labelledby="mobileNavbarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="mobileNavbarLabel">Menú</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Cerrar"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav">
          <li class="nav-item"><a class="nav-link text-white" href="index.html">Inicio</a></li>
          <li class="nav-item"><a class="nav-link text-white" href="cursos.php">Cursos</a></li>
          <li class="nav-item"><a class="nav-link text-white" href="areadepracticas.html">Área de Práctica</a></li>
          <li class="nav-item"><a class="nav-link text-white" href="nosotros.html">Nosotros</a></li>
          <li class="nav-item"><a class="nav-link text-white" href="https://forms.gle/ZTZrzaAK1NZHGCKE6" target="_blank">Inscríbete</a></li>
          <li class="nav-item dropdown">
            <a class="nav-link text-white" href="#" role="button" data-bs-toggle="dropdown">Galería</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="Galerias.html#seccion1">SolidWorks Básico</a></li>
              <li><a class="dropdown-item" href="Galerias.html#seccion2">Control Eléctrico Industrial</a></li>
              <li><a class="dropdown-item" href="Galerias.html#seccion3">Programación CNC</a></li>
              <li><a class="dropdown-item" href="Galerias.html#seccion4">Instalaciones Eléctricas</a></li>
              <li><a class="dropdown-item" href="Galerias.html#seccion5">Mantenimiento Minisplit</a></li>
              <li><a class="dropdown-item" href="Galerias.html#seccion6">Marketing Digital</a></li>
              <li><a class="dropdown-item" href="Galerias.html#seccion7">Programación PLC</a></li>
              <li><a class="dropdown-item" href="Galerias.html#seccion8">Respuesta Inmediata contra Incendios</a></li>
              <li><a class="dropdown-item" href="Galerias.html#seccion9">Montacargas</a></li>
              <li><a class="dropdown-item" href="Galerias.html#seccion10">Condiciones de Seguridad Para Realizar Trabajos en Trabajos en Altura</a></li>
            </ul>
          </li>
          <li class="nav-item"><a class="nav-link text-white" href="ubicanos.html">Ubícanos</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

  <main>
    <div class="container mt-5 mb-5">
      <div class="row row-cols-1 row-cols-md-3 g-4">
<?php
  include 'db.php'; // Asegúrate de que la ruta sea correcta
  $query = "SELECT * FROM cursos ORDER BY id DESC";
  $resultado = $conexion->query($query);

  while ($curso = $resultado->fetch_assoc()) {
    echo '
    <div class="col">
      <div class="card h-100 curso-card">
        <img src="' . $curso["imagen"] . '" class="card-img-top">
        <div class="card-body">
          <h5 class="card-title"><strong>' . $curso["titulo"] . '</strong></h5>
          <p class="card-text">' . $curso["descripcion"] . '</p>
        </div>
        <div class="card-footer d-flex flex-column align-items-center gap-2">
          <div class="d-flex justify-content-center gap-4">
            <small><i class="bi bi-calendar-event"></i> ' . $curso["fecha"] . '</small>
            <small><i class="bi bi-alarm"></i> ' . $curso["horario"] . '</small>
          </div>
          <hr style="border: 1px solid rgba(255,255,255,0.5); width: 100%;">
          <div class="d-flex justify-content-between w-100 px-3 flex-wrap">
            <small><i class="bi bi-clock-history"></i> ' . $curso["duracion"] . '</small>
            <small><i class="bi bi-calendar-week"></i> ' . $curso["dias"] . '</small>
            <small><i class="bi bi-people-fill"></i> ' . $curso["alumnos"] . ' alumnos</small>
          </div>
        </div>
      </div>
    </div>';
  }
?>

      </div>
    </div>
  </main>

<!-- Footer -->
<div class="main">
  <footer>
    <div class="waves">
      <div class="wave" id="wave1"></div>
    </div>

    <div class="container position-relative">

      <!-- Redes sociales (CENTRO) -->
      <div class="position-absolute top-50 start-50 translate-middle d-flex justify-content-center">
        <div class="zoom">
          <ul class="social_icon d-flex justify-content-center mb-0">
            <li><a href="https://facebook.com/CeijJuarez"><ion-icon name="logo-facebook"></ion-icon></a></li>
            <li><a href="https://www.instagram.com/ceij_juarez"><ion-icon name="logo-instagram"></ion-icon></a></li>
            <li><a href="https://www.tiktok.com/@ceijjuarez"><ion-icon name="logo-tiktok"></ion-icon></a></li>
            <li><a href="https://www.youtube.com/@CEIJJUAREZ"><ion-icon name="logo-youtube"></ion-icon></a></li>
            <li><a href="https://wa.me/5216566367848"><ion-icon name="logo-whatsapp"></ion-icon></a></li>
            <li><a href="mailto:ceij030223@gmail.com"><ion-icon name="mail-outline"></ion-icon></a></li>
          </ul>
        </div>
      </div>

      <!-- Descarga App (DERECHA en desktop, centrado abajo en móvil) -->
      <div class="d-flex flex-wrap justify-content-center justify-content-md-end gap-3">
        
        <div class="d-flex flex-wrap justify-content-center justify-content-md-end gap-3">

          <!-- APK -->
          <a href="https://github.com/ceij030223-cloud/CEIJ_APP/releases/download/%3CCEIJ/app_ceij.1.apk"
             class="btn btn-dark d-flex align-items-center gap-2 px-3 py-2"
             target="_blank"
             style="height:50px;">
            <i class="fab fa-github"></i> Descargar APK
          </a>

          <!-- Google Play -->
          <a href="https://play.google.com/store/apps/details?id=app.ceij"
             target="_blank"
             class="btn btn-dark d-flex align-items-center px-2 py-0"
             style="height:50px; background-color:#000; border:none;">
            <img alt="Disponible en Google Play"
                 src="https://play.google.com/intl/en_us/badges/static/images/badges/es_badge_web_generic.png"
                 style="height:100%;"/>
          </a>

        </div>
      </div>

    </div>

    <p class="mt-3 text-center">© 2025 Todos los derechos reservados.</p>
  </footer>
</div>
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  <script>AOS.init();</script>
</body>
</html>