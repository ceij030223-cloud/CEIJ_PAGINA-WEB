<?php
include 'db.php';

if (!isset($_GET['admin']) || $_GET['admin'] !== 'adminceij123') {
    die("Acceso no autorizado.");
}

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "DELETE FROM cursos WHERE id = $id";
    if ($conexion->query($query)) {
        header("Location: admin.php?admin=adminceij123");
        exit();
    } else {
        echo "Error al eliminar el curso: " . $conexion->error;
    }
} else {
    echo "ID inválido.";
}
?>
